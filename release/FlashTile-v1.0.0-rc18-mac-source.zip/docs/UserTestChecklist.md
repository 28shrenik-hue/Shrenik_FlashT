# FlashTile v1.0 RC18 User Test Checklist

Run `START_FLASHTILE_MAC.command` on macOS or `scripts\run_windows.bat` on
Windows, then verify:

## Startup and shell

- The self-check reports PASS and the tile opens.
- The tile appears on the primary display near the upper-right.
- Its size remains 410 × 690 and it never expands full screen.
- The liquid-glass logo, wordmark, XP, streak, and close control are visible.
- The tile can be dragged and remains above ordinary windows.
- After dragging and relaunching, the tile returns to its last valid screen position.
- The Welcome and Learning Goal steps display `1.0.0-rc18`.
- The Welcome Tile enters once with a short, calm reveal; the logo does not pulse continuously.
- Continue and Back use a compact content transition with no full-screen expansion.
- Reduced-motion mode removes the startup and content-transition choreography.

## Learning flow

- The main dropdown contains the three flagship areas and all six prepared subjects.
- Each prepared subject opens its exact named lesson rather than a generic first lesson.
- The six prepared subjects are Risk & Decision Making; BCBS 239 & Data Governance; Human-in-the-loop AI controls; Issues & Errors Management; Legal-obligation impact assessments; and Alternative investments and portfolio diversification.
- Typing a custom learning goal displays no predictive suggestions or auto-completion.
- A recognized custom request starts the correct prepared path.
- An unavailable request is saved locally and a duplicate is not added twice.
- Core Concept advances to Practical Scenario, Go Deeper, and Knowledge Check.
- Back controls return to the correct stage.
- An incorrect answer shows feedback and allows retry.
- A correct answer enables completion and awards XP once.
- Confidence selection schedules the next review.
- Next flash loads new content with the approved transition.
- Each of the three learning goals opens the matching category and remains within it.
- Next flash follows the selected path across topics and resumes after relaunch.

## Learning tools

- Bottom controls appear in this order: Learning Goals, Saved Lessons, Meditation, Daily Discovery, Quick Notes.
- Hovering over each bottom control shows its exact function name.
- Bookmark saves the current lesson and Saved Review can reopen it.
- Quick Notes saves, edits, clears, and restores a takeaway after relaunch.
- Saved Takeaways lists every note and can reopen or remove it.
- Selecting a category filters lesson search and every subsequent lesson to that category.
- The center breathing control completes its 60-second cycle and records no data.
- Daily Discovery opens a complete offline card and Show Another loads a different card.
- The header Team Board control opens a complete six-member capability demo.
- Team Board contains no notes, answers, or confidence data.
- Weekly XP, streak, lesson goal, progress bar, and all six contributors fit without clipping.
- The Team Board shows the weekly challenge and team-badge reward.
- Clicking XP opens Personal Progress with accurate overall and per-topic metrics.
- Achievement Badges displays six badges and unlocks First Step after one completion.
- Lesson Search finds lessons by title, topic, or description and opens the result.
- The `?` control starts a complete seven-step Guided Tour.
- Every Daily Discovery card displays a named source link.
- Reset Progress requires confirmation, creates a timestamped backup, and clears local activity.

## Persistence and recovery

- XP, streak, topic, lesson position, bookmarks, notes, and mastery survive relaunch.
- Topic requests and the selected window position survive relaunch.
- `~/.flashtile/backups/` contains a dated workbook backup after a change.
- `~/.flashtile/logs/FlashTile.log` records startup.

## Visual behavior

- Mouse movement creates the approved restrained swivel.
- Hover glow, background parallax, stage transitions, and light sweep remain smooth.
- No text or controls are clipped at any learning stage.
- The experience remains usable with the trackpad and keyboard.
- Reduced motion disables swivel, card transitions, pulses, and breathing-circle scaling.
- `Ctrl+G`, `Ctrl+B`, `Ctrl+N`, `Ctrl+D`, `Ctrl+T`, `Ctrl+F`, and `Ctrl+P` open their matching tools; `F1` opens the Guided Tour.

Record the operating system, display scaling, pass/fail item, and a screenshot or
log excerpt for every issue.
