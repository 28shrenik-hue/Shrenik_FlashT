"""FlashTile domain models."""

