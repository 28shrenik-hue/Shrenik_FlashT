"""FlashTile application package."""

